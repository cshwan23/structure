import UIKit

// struckture 구조체 -관련된 데이터들을 패키지처럼 쓰는건데

//한 반에 학생들이 네명 있다고 생각을하고 학생들의 데이터를 관리한다고 생각해보죠

var name = ["승환","영진","태연","아이린"]
var age = [31,30,32,31]
var height = [66,63,48,49]

//데이터를 출력하려면
print(name[0], age[0], height[0])

// 그사람의 정보만 모아두고싶다.

struct Student{
    var name:String
    var age:Int
    var height:Int
}
// 모든 struct type은 자동으로 프로펄티가 나온다
var student1 = Student(name: "승환", age: 31, height: 66)
var student2 = Student(name: "영진", age: 30, height: 63)

print(student1.name, student1.age, student1.height)
